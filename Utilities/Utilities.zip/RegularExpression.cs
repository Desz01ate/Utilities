﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace Utilities
{
    public static class RegularExpression
    {
        private static Match RegexMatch(string input, string pattern)
        {
            return new Regex(pattern).Match(input);
        }
        public static bool IsPhoneNumber(string input, string pattern = @"^(08|\+66)\d{8}") => RegexMatch(input, pattern).Success;
        public static bool IsEmail(string input, string pattern = @"[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?") => RegexMatch(input, pattern).Success;
        public static bool IsNumber(string input) => RegexMatch(input, @"^\d+$").Success;
        //\u0E00-\u0E7F isa unicode for Thai language
        public static bool IsText(string input) => RegexMatch(input, @"^[\u0E00-\u0E7Fa-zA-z]+").Success;
    }
}
